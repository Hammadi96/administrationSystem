var express = require('express');
var router = express.Router();
const cors = require("cors");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const employee = require("./model/employee");

mongoose
  .connect(
    "mongodb://localhost:27017/101197058_assignment2"    
  )
  .then(() => {    
    console.log("Connected to database!");
   
  })
  .catch(() => {
    console.log("Connection failed!");
  });

mongoose.Promise = global.Promise;
const app = express();
app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));

//Get Employees
app.get("/api/v1/employees", (req, res) => {    
  // ,{_id:0},  
  employee.find({},(err,docs)=>{  
    res.status(200).json(docs);
    console.log("All employee resources are fetched.");        
  });
});
  
//Get Employee
app.get("/api/v1/employees/:id", (req, res) => {    
  var id = req.params.id
  employee.findById({ "_id": id},function(err,docs){
    if (err){
      if (docs==null){
        res.sendStatus(404);
        console.log("No valid entry found for provided ID");
      }else{
        console.log(err);
        res.sendStatus(500);
      }
    }
    else{
      {
        res.status(200).json(docs);
        console.log("One employee resource is fetched.");        
      }
    }
  });
});

// Post employee
app.post("/api/v1/employees", (req, res) => {    
  const employee1 = new employee({    
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    emailId: req.body.emailId,
  }); 
  
  employee1.save(function(err,result){        
    if (err){      
        console.log('Error Inserting New Data');         
        res.status(500).json({
          error: err          
        })
    }
    else{
      console.log("A new employee resource is created");      
      res.sendStatus(201); 
    }
  })
});

// Update employee
app.put("/api/v1/employees/:id", function (req, res) {  
  var id =req.params.id  
  employee.findByIdAndUpdate({_id: id},req.body, (err, res1) => {    
    if (res==null){      
      console.log('Error Updating New Data');         
      res.status(500).json({
        error : err      
      });
    }
    else{
      if (res==null){
        res.sendStatus(404);
        console.log("No valid entry found for provided ID");
      }else{
        console.log("Employee resource is updated");
        employee.findOne({_id: id}).then(function(employee){
          res.status(200).json(employee);
        });        
      }            
    }    
  });
}); 


//Delete employee
app.delete("/api/v1/employees/:id", (req, res) => {
  const id= req.params.id;
  employee.deleteOne({ _id: id }).then(result => {  
    console.log("Employee resource is deleted");      
    res.status(200).json({
      message: "Employee resource is deleted"
    });
  }).catch(err=>{
    res.status(500).json({      
      message: "error"
    })
  });
});
/*console.log("Employee resource is deleted");
      res.status(204).json*/
app.use((err, req, res, next) => {
    res.status(err.status || 400);
    res.json({
      firstName: err.firstName,
      lastName: err.lastName,
      emailId: err.emailId,      
    });
    
});
  
const port = parseInt(process.env.PORT || "7100");
app.listen(port, () => console.log(`Listening on port ${port}`));