const mongoose = require('mongoose');

const employee = new mongoose.Schema({  
  firstName: { 
    type: String,
    required: [true, 'firstname cannot be blank. it is mandatory field']
  },
  lastName: { 
    type: String,
    required: [true, 'lastname cannot be blank. it is mandatory field']
  },
  emailId: {   
    type: String,
    required: [true, 'email is required field'],    
    match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Please give a valid email address']
  },  
},{
  versionKey: false // You should be aware of the outcome after set to false
});
var collectionName = 'employee'
module.exports = mongoose.model('Employee', employee ,collectionName);
var entitySchema = mongoose.Schema({
  sort: {type: String}
});
