import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link, useNavigate, useParams } from "react-router-dom";

const EditEmployee = () => {
    let navigate = useNavigate();
    const { id } = useParams();
    // console.log(id);
    const [employee, setEmployee] = useState({
        firstName: "",
        lastName: "",
        emailId: ""
    });
    useEffect(() => {
        loadEmployee();
    }, []);

    const onInputChange = e => {
        setEmployee({ ...employee, [e.target.name]: e.target.value })
    }

    const loadEmployee = async e => {
        // e.preventDefault();
        const result=await axios.get(`http://localhost:7100/api/v1/employees/${id}`)      
        setEmployee(result.data);

    };
    const onSubmit = async e => {
        e.preventDefault();
        await axios.put(`http://localhost:7100/api/v1/employees/${id}`, employee);
        navigate('/');
    }
    return (
        <div style={{ marginRight: 120, marginLeft: 450 }}>
            <table class="table boarder  shadow" style={{ margin: 50 }} >
                <div className='col-sm-10'>
                    <div classNam="w-75 mx-auto  p-5 shadow">
                        <h2 className="text-center mb-4"> Edit Employee</h2>
                        <form onSubmit={e => onSubmit(e)} style={{ marginLeft: 20 }}>
                            <div class="form-group" >
                                <label for="exampleFormControlInput1">First Name:</label>
                                <input
                                    required type="text"
                                    class="form-control"
                                    id="exampleFormControlInput1"
                                    placeholder="firstName"
                                    name="firstName"
                                    value={employee.firstName}
                                    onChange={e => onInputChange(e)}
                                />

                            </div>
                            <br />
                            <div class="form-group">
                                <label for="exampleFormControlInput1">Last Name:</label>
                                <input
                                    required type="text"
                                    class="form-control" id="exampleFormControlInput1" placeholder="Last Name"
                                    name="lastName"
                                    value={employee.lastName}
                                    onChange={e => onInputChange(e)}
                                />
                            </div>
                            <br />
                            <div class="form-group">
                                <label for="exampleFormControlInput1">Email id:</label>
                                <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="email Address"
                                    name="emailId"
                                    value={employee.emailId}
                                    onChange={e => onInputChange(e)}
                                />
                            </div>
                            <div class="form-group form-check">
                            </div>
                            <br />
                            <button type="submit" class="btn btn-warning" style={{ marginRight: 16 }}> Update </button>
                            <Link class="btn btn-primary" to="/"> Cancel </Link>
                        </form>
                    </div>
                </div>
            </table>
        </div>
    )
};

export default EditEmployee;