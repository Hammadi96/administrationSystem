import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";

const ViewEmployee = () => {    
    const { id } = useParams();
    // console.log(id);
    const [employee, setEmployee] = useState({
        firstName: "",
        lastName: "",
        emailId: ""
    });
    useEffect(() => {
        loadEmployee();
    }, []);

    const loadEmployee = async e => {
        // e.preventDefault();
        const result = await axios.get(`http://localhost:7100/api/v1/employees/${id}`)
        setEmployee(result.data);

    };
    return (
        <div style={{ marginRight: 120, marginLeft: 450 }}>
            <table class="table boarder  shadow" style={{ margin: 50 }} >
                <div className='col-sm-10'>
                    <div classNam="w-75 mx-auto  p-5 shadow">
                        <h2 className="text-center mb-4"> Employee Details</h2>
                        <form style={{ marginLeft: 20 }}>
                            <div class="form-group" >
                                <label for="exampleFormControlInput1" style={{marginRight: 25}}>First Name:</label>
                                <label for="exampleFormControlInput1">{employee.firstName} </label>                                
                            </div>
                            <br />
                            <div class="form-group">
                                <label for="exampleFormControlInput1" style={{marginRight: 25}}>Last Name:</label>
                                <label for="exampleFormControlInput1">{employee.lastName} </label>
                            </div>
                            <br />
                            <div class="form-group">
                                <label for="exampleFormControlInput1" style={{marginRight: 43}}>Email id:</label>
                                <label for="exampleFormControlInput1">{employee.emailId} </label>
                            </div>
                            <div class="form-group form-check">
                            </div>
                            <br />                            
                            <Link class="btn btn-primary" to="/"> Back </Link>
                        </form>
                    </div>
                </div>
            </table>
        </div>
    )
}
export default ViewEmployee;