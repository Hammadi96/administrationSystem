import React, {useState} from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

const AddEmployee = () => {
    let navigate= useNavigate();
    const [employee, setEmployee]= useState({        
        firstName: "",
        lastName: "",
        emailId: ""
    });

    const onInputChange = e =>{
        setEmployee({...employee,[e.target.name]: e.target.value})
    }

    const onSubmit = async e => {
        e.preventDefault();
        await axios.post("http://localhost:7100/api/v1/employees", employee);
        navigate('/');
    }
    return (
        <div style={{ marginRight: 120 ,marginLeft: 450 }}>            
                <table class="table boarder  shadow" style={{ margin: 50 }} >
                    <div className='col-sm-10'>
                        <div classNam="w-75 mx-auto  p-5 shadow">
                            <h2 className="text-center mb-4"> Add an Employee</h2>
                            <form onSubmit={e => onSubmit(e)} style={{marginLeft: 20}}>
                                <div class="form-group" >
                                    <label for="exampleFormControlInput1">First Name:</label>
                                    <input 
                                        required
                                        type="name" 
                                        class="form-control" 
                                        id="exampleFormControlInput1" 
                                        placeholder="firstname" 
                                        name="firstname"
                                        value= {employee.firstName}                                        
                                        onChange={e => onInputChange(e)}
                                    />
                                    
                                </div>
                                <br />
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Last Name:</label>
                                    <input 
                                        required
                                        class="form-control" id="exampleFormControlInput1" placeholder="Last Name" 
                                        name="lastname"
                                        value= {employee.lastName}
                                        onChange={e => onInputChange(e)}
                                    />
                                </div>
                                <br />
                                <div class="form-group">
                                    <label for="exampleFormControlInput1">Email id:</label>
                                    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Email Address" 
                                        name="emailid"
                                        value= {employee.emailId}
                                        onChange={e => onInputChange(e)}
                                    />
                                </div>
                                <br/>
                                <button class="btn btn-success" style={{marginRight: 16}}> Add </button>
                                <Link  class="btn btn-danger" to="/"> Cancel </Link>
                            </form>
                        </div>
                    </div>
                </table>
            </div>        
    )
};

export default AddEmployee;