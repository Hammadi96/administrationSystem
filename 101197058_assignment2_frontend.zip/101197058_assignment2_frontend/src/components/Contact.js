import React from "react";

const Contact = () =>{
    return (
        <div className="container">
            <div className="py-4">
                <h1> Contact page</h1>
                <br />
                <h3> No Contact details</h3>
            </div>
            
        </div>
    );
};

export default Contact;