import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";


const Home = () => {
    const [employee, setEmployee] = useState([]);

    useEffect(() => {
        loadEmployee();
    }, []);
    const deleteUser = async id => {
        await axios.delete(`http://localhost:7100/api/v1/employees/${id}`)
        loadEmployee();
    }

    const loadEmployee = async () => {
        const result = await axios.get("http://localhost:7100/api/v1/employees")
        setEmployee(result.data);
        // console.log(result.data[0]._id)
    };
    return (
        <div className="container">
            <div>
                <br />

                <div className='row'>
                    <div className='col-sm-6'>
                        <h2>Employees</h2>
                    </div>
                    <div className='col-sm-5' style={{ textAlign: 'right' }}>
                        <Link className='btn btn-outline-primary' to="/employees/add">Add Employee</Link>
                    </div>
                    <div className='col-sm-2'></div>
                </div>

                <br />
                <br />

                <table class="table boarder  shadow">
                    <thead className='table-dark'>
                        <tr class="bg-bg-light">
                            <th scope="col" >#</th>
                            <th scope="col">FirstName</th>
                            <th scope="col">LastName</th>
                            <th scope="col">Email id</th>
                            <th style={{ textAlign: 'center' }}>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {employee.map((employee, index) => (
                            <tr>
                                <th scope="row">{index + 1} </th>
                                <td> {employee.firstName}</td>
                                <td> {employee.lastName}</td>
                                <td> {employee.emailId}</td>
                                <td style={{ textAlign: 'center' }}>
                                    <div className='btn-group' >
                                        <Link class="btn btn-outline-primary" to={`/employee/${employee._id}`}> View</Link>
                                        <Link class="btn btn-outline-success" to={`/employees/edit/${employee._id}`} > Edit</Link>
                                        {/* <Link class="btn btn-outline-success" to="/employees/edit/:id" > Edit</Link> */}
                                        <Link class="btn btn-outline-danger" onClick={()=> deleteUser(employee._id)} to=""> Delete</Link>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default Home;
