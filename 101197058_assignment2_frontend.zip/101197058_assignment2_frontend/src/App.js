import React from 'react';

import "../node_modules/bootstrap/dist/css/bootstrap.css"
import Home from "./components/Home";
import About from './components/About';
import Contact from './components/Contact';
import Navbar from './components/layout/Navbar';
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import AddEmployee from './components/Employee/AddEmployee';
import EditEmployee from './components/Employee/EditEmployee';
import ViewEmployee from './components/Employee/ViewEmployee';

function App() {
  return (
    <Router>
      <div className="App">
        <Navbar />
        <Routes>
            <Route exact path="/home" element={<Home />} />
            <Route exact path="/" element={<Home />} />
            <Route exact path="/about" element={<About />} />
            <Route exact path="/contact" element={<Contact />} />
            <Route exact path="/employees/add" element={<AddEmployee />} />
            <Route exact path="/employees/edit/:id" element={<EditEmployee />} />
            <Route exact path="/employee/:id" element={<ViewEmployee />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;

